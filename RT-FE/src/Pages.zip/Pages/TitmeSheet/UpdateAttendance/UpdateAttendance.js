import MainPage from "../../../Components/Common/MainPage";
import Table from "./Table";

export default function UpdateAttendance() {
    return(
        <MainPage title={"Update Attendance"}>
            <Table/>
        </MainPage>
    )
};
