import MainPage from "../../../Components/Common/MainPage";
import Table from "./Table";

export default function OvertimeRequest() {
    return(
        <MainPage title={"Overtime Request"}>
            <Table/>
        </MainPage>
    )
};
