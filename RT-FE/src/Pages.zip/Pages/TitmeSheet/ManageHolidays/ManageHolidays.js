import MainPage from "../../../Components/Common/MainPage";
import Table from "./Table";

export default function ManageHolidays() {
    return(
        <MainPage title={"Manage Holidays"}>
            <Table/>
        </MainPage>
    )
};
