import MainPage from "../../../Components/Common/MainPage";
import Table from "./Table";

export default function ManageLeave() {
    return(
        <MainPage title={"Manage Leaves"}>
            <Table/>
        </MainPage>
    )
};
