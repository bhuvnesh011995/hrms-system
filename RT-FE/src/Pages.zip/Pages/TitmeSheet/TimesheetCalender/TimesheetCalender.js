import MainPage from "../../../Components/Common/MainPage";
import Filter from "./Filter";

export default function TimesheetCalender() {
    return(
        <MainPage title={"Timesheet Calendar"}>
            <Filter/>
        </MainPage>
    )
};
