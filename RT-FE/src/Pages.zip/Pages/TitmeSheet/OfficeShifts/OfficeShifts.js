import MainPage from "../../../Components/Common/MainPage";
import Table from "./Table";

export default function OfficeShifts() {
    return(
        <MainPage title={"office Shifts"}>
            <Table/>
        </MainPage>
    )
};
