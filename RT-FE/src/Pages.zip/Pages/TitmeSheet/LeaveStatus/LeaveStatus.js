import MainPage from "../../../Components/Common/MainPage";
import Table from "./Table";

export default function LeaveStatus() {
    return(
        <MainPage title={"Leave Status"}>
            <Table/>
        </MainPage>
    )
};
