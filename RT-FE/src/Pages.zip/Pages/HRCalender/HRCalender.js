import MainPage from "../../Components/Common/MainPage";
import CalenderAndEvent from "./CalenderAndEvent";

export default function HRCalender() {
    return(
        <MainPage title={"HR Calendar"}>
            <CalenderAndEvent/>
        </MainPage>
    )
};
