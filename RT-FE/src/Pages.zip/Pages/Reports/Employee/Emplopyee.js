import MainPage from "../../../Components/Common/MainPage";
import Table from "./Table";

export default function Emplopyee() {
    
};
