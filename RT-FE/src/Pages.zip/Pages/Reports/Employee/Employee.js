import MainPage from "../../../Components/Common/MainPage";
import Table from "./Table";


export default function Employee() {
    return(
        <MainPage title={"View Employees Report"}>
            <Table/>
        </MainPage>
    )
};
