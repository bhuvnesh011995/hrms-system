import MainPage from "../../../Components/Common/MainPage";
import Table from "./Table";

export default function CPFSubmission() {
    return(
        <MainPage title={"CPF Submission"}>
            <Table/>
        </MainPage>
    )
};
