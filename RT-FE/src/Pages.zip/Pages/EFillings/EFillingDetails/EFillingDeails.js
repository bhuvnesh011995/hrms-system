import MainPage from "../../../Components/Common/MainPage";
import Form from "./Form";

export default function EFillingDeails() {
    return(
        <MainPage title={"Employer's Filing Details"}>
            <Form/>
        </MainPage>
    )
};
