import MainPage from "../../../Components/Common/MainPage";
import EmployeeTable from "./EmployeeTable";

export default function Transfer() {
    return(
        <MainPage title="Transfer">

            <EmployeeTable/>
        </MainPage>
    )
};
