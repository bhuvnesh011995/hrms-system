import MainPage from "../../../Components/Common/MainPage";
import EmployeeTable from "./EmployeeTable";

export default function EmployeeExit() {
    return(
        <MainPage title={"Employee Exit"}>

            <EmployeeTable/>
        </MainPage>
    )
};
