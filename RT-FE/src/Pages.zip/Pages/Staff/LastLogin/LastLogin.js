import MainPage from "../../../Components/Common/MainPage";
import EmployeeTable from "./EmployeeTable";

export default function LastLogin() {
    return(
        <MainPage title={"Last Login"}>

            <EmployeeTable />
        </MainPage>
    )
};
