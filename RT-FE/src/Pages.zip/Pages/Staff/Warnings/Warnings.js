import MainPage from "../../../Components/Common/MainPage";
import EmployeeTable from "./EmployeeTable";

export default function Warnings() {
    return(
        <MainPage title={"Warnings"}>
            <EmployeeTable/>
        </MainPage>
    )
};
