import MainPage from "../../../Components/Common/MainPage";
import FilterStaff from "./FilterStaff";

export default function StaffDirectory() {
    return(
        <MainPage title="Staff Directory">

            <FilterStaff />
        </MainPage>
    )
};
