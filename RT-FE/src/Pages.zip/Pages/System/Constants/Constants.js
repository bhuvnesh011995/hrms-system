
import MainPage from "../../../Components/Common/MainPage";
import TabOfCon from "./Tab";
import Tabs from "./Tabs";

export default function Constants() {
    return(
        <MainPage title={"Constants"}>
            <TabOfCon/>
        </MainPage>
    )
};

