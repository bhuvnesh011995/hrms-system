import MainPage from "../../../Components/Common/MainPage";
import Tabs from "./Tabs";

export default function Settings() {
    return(
        <MainPage title={"SETTINGS"}>
            <Tabs/>
        </MainPage>
    )
};
