import MainPage from "../../../Components/Common/MainPage";
import Table from "./Table";

export default function Departments() {
    return(
        <MainPage title={"Department"}>
            <Table/>
        </MainPage>
    )
};
