import MainPage from "../../../Components/Common/MainPage";
import Table from "./Table";

export default function Locations() {
    return(
        <MainPage title={"Location"}>
            <Table/>
        </MainPage>
    )
};
