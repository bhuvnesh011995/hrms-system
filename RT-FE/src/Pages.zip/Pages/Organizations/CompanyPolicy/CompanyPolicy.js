import MainPage from "../../../Components/Common/MainPage";
import Table from "./Table";

export default function CompanyPolicy() {
    return(
        <MainPage title={"Policies"}>
            <Table/>
        </MainPage>
    )
};
