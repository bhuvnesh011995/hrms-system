import MainPage from "../../../Components/Common/MainPage";
import Table from "./Table";

export default function OfficialDocuments() {
    return(
        <MainPage title={"Official Documents"}>
            <Table/>
        </MainPage>
    )
};
