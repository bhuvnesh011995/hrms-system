import MainPage from "../../../Components/Common/MainPage";
import Table from "./Table";

export default function SubDepartment() {
    return(
        <MainPage title={"Sub Department"}>
            <Table/>
        </MainPage>
    )
};
