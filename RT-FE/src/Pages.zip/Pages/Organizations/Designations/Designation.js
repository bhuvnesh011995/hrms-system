import MainPage from "../../../Components/Common/MainPage";
import Table from "./Table";

export default function Designation() {
    return(
        <MainPage title={"Designation"}>
            <Table/>
        </MainPage>
    )
};
