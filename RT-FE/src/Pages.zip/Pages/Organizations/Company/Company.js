import MainPage from "../../../Components/Common/MainPage";
import Table from "./Table";

export default function Company() {
    return(
        <MainPage title={"COMPANY"}>
            <Table/>
        </MainPage>
    )
};
